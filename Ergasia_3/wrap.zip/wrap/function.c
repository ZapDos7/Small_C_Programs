/* Greedy Method Function */
#include <stdio.h>
int function (int *pinakas, int W, unsigned long long cost)
{
	long h=0,  j;					/* h refers to letters of each word and j to amount of spaces --> cost*/
	long long k=0;					/* Amount of Characters, begin with first */
	j=W;						/* Line Limit Length */
	while(pinakas[k]!='\0'){			/* Till the end */
		if (h>j){
			pinakas[k-h-1]='\n';
			j++;
			cost=cost+j*j;
			j=W-h-1;
			h=0;
		}
		else if (h+1==j){
			j=W;
			cost=cost+1;
			h=0;
			pinakas[k]='\n';
		}
		else if (pinakas[k]!=' ') h++;		/* If the word is over just move on */
		else if (h==j){				/* End */
			j=W;
			h=0;
			pinakas[k]='\n';
		}
		else if (h<j-1){
			j=j-h-1;
			h=0;
		}
		k++;
	}
	if (cost==0){
		j++;
		cost=cost-j*j;
	}
	return 0;
}
