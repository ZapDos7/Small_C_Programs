int* function (int *pinakas, int W, unsigned long long cost);
