/* Greedy Method Function */
#include <stdio.h>
int function (int *pinakas, int W, unsigned long long cost)
{
	long h=0,  j;					/* h refers to word length and j to amount of spaces --> cost*/
	long long i=0;					/* Amount of Characters, begin with first */
	j=W;						/* Line Limit Length */
	while(pinakas[i]!='\0'){			/* Till the end */
		
		}
		i++;
	}
	if (cost==0){
		j++;
		cost=cost-j*j;
	}
	return 0;
}
