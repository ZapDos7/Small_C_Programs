/* File: erg3.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "function.h"

int main (int argc, char *argv[])
{
	int W, spaces=0, ch, *temp, count=0, lekseis=0, *final;
	long max=8, i=0;
	unsigned long long cost=0;
	if (argc==2){
		W=atoi(argv[1]);
	}
	else if (argc==1){
		W=80;
	}
	else printf("ERROR - NEED VALUE FOR LINE LENGTH. :/\n");
	temp=malloc(max*sizeof(char));
	while ((ch=getchar())!=EOF){
		if (ch==' '||ch=='\t'||ch=='\n'){
		spaces=1;
		}
		if (i>max){
			max=max*2;
			temp=realloc(temp, max*sizeof(char));
		}
		if (spaces && !isspace(ch)){
			temp[i]=' ';
			spaces=0;
			i++;
			temp[i]=ch;
			i++;
			lekseis++;
		}
		else if (!spaces && !isspace(ch)){
			temp[i]=ch;
			i++;
		}
		else continue;
	}
	if (temp==NULL){
		printf("Not enough memory!\n");
		return 1;
	}
	final=malloc(max*sizeof(char)+1);
	final=function(temp, W, cost);
	for (count=0;count<i-1;count++){
		printf("%c", temp[count]);
		putchar('\n');
	}
	printf("Width=%d, Words=%d, Cost=%lld.\n", W, lekseis, cost);
	free(temp);
}
